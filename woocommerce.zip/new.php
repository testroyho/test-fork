<?php

$new = 1233;